package dominion;

public class Treasure extends Card
{
	public Treasure(int name)
	{
		super(name);
	}
/*
        @Override
	public void print()
	{
		System.out.println("Treasure Card: ");
		super.print();
	}
*/
	void buy()
	{

	}
}


